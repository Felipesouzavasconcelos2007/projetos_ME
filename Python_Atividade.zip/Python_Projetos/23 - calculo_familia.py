gastos = (30.00,40.00,50.00,30.00)
soma = 0
for valores in gastos:
    soma+= valores

print('A soma dos gastos foi:',soma)