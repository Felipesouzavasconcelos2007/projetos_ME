produtos_cadastrados = ['Bolsa', 'Pao','Bola','Boia']
print('A loja tem',len(produtos_cadastrados),'produtos cadastrados')