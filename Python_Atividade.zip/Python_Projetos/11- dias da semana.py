mf= float(input('Digite sua media final: '))
if mf >= 8.0 :
    print('Você pode concorrer ao processo seletivo!!')
else :
    print('Voce não pode concorrer ao processo seletivo!!')