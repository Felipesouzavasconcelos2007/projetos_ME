dict_medicamentos = {
}
for medicamentos in range(5):
    nome_med = str(input('Digite o nome do medicamento: '))
    qunt_med = int(input(f'Digite a quantidade do medidicamento {nome_med} esta disponivel: '))
    dict_medicamentos[nome_med] = qunt_med

consulta_med = str(input('''Qual medicamento você deseja consultar? 
Digite Aqui: '''))
print('A quantidade total do medicamento disponivel no estoque foi:',dict_medicamentos[consulta_med])