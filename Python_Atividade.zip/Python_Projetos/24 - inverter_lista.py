ordem_chegada = ('Claudio', 'Felipe', 'Cleiton', 'Junior')
lista_invertida = tuple(reversed(ordem_chegada))
print(' Ordem correta foi',lista_invertida)