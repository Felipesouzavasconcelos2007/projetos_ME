lista = [123,456,789,101112]
cod = 123

if cod in lista:
    print('O codigo esta presente na lista!')