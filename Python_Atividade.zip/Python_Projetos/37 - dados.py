from random import randint

dado = randint(1,6)

print('O numero do dado sorteado foi',dado)