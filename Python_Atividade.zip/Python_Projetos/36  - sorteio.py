from random import randint 

num_winer = randint(1,50)

print(f'O numero do vencedor é {num_winer}!!!')

