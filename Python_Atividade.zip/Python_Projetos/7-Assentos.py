for assentos in range(1,21):
    print(f'Assento {assentos}')