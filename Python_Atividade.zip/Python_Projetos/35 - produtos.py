produtos = {
    "arroz": 11 , 
    "feijão": 14,
    "macarrão": 12
}

print(produtos)