alunos = [
    ['Aluno 1', 'Aluno 2'],
    ['Aluno 3', 'Aluno 4']
]
for fileira in alunos:
    print(fileira)