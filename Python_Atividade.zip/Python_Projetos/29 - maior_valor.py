tuplas_vlr = (200.00,300.00,100.00,550.00)
maior_vlr= max(tuplas_vlr)
print('O maior valor entres as vendas foi ',maior_vlr)