aluno = {
}
aprovados = {

}
soma = 0
media = 0
cont = 0

for cadastro in range(5):
    nome_aluno = str(input('Digite o nome do aluno: '))
    nota_aluno = float(input(f'Digite a nota do aluno {nome_aluno}'))

    aluno[nome_aluno] = nota_aluno

    soma += nota_aluno
    cont+=1

    if nota_aluno >= 7 :
        aprovados[nome_aluno] = "Aprovado"
    else:
        aprovados[nome_aluno] = "Reprovado"

    
media = soma / cont

print(aluno)
print(aprovados)
print(f'A media da turma foi {media}')   