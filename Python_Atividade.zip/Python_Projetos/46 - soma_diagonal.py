valores = [
    [123,345,567],
    [789,101,111],
    [121,131,141]
]
soma = 0
for i in range(len(valores)):
    soma +=valores[i][i]

print('A soma da diagonal é :',soma)