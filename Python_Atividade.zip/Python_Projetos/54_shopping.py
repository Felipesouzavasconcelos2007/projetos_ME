matriz = [
    [1,0,1],
    [1,1,0],
    [0,1,1]
]
cont_vagas = 0
cont_cheia = 0
for linha in matriz:
    for vargas in linha:
        if vargas == 0 :
            cont_vagas+=1
        else: 
            cont_cheia+=1

print('Tem',cont_vagas,'vagas livres')
print('tem ',cont_cheia,'vagas ocupadas')