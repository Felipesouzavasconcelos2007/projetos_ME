velocidade_max = float(input('Digite a sua velocidade: '))

if velocidade_max >= 80.00:
    print('Você ultrapassou o limite maximo permitido !!')
else:
    print('Você não ultrapassol o limite maximo!!')