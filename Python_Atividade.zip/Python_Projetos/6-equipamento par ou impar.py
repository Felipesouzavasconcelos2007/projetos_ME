cod_equipa = int(input('Digite o codigo do equipamento: '))

if cod_equipa % 2 == 0:
    print('Este equipamento é par!')
else: 
    print('Este equipamento é impar!')
    