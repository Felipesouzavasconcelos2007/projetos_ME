vlr_compra = float(input('Digite o valor da compra:R$ '))

if vlr_compra >= 500.00:
    print('Tem direito ao beneficio!!!')
else:
    print('Não tem direito ao beneficio!!!')