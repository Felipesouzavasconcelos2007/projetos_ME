soma= 0 
total = 0
for total_arreacadado in range(5):
    arrecadacao = int(input('Digite a sua arrecadação: '))
    soma+=arrecadacao

print(f'O total arrecadado foi {soma} alimentos.')