tupla_teperaturas = (22,26,29,32)
soma = sum(tupla_teperaturas)
print(f'A soma das temperaturas registradas foi: {soma}')



