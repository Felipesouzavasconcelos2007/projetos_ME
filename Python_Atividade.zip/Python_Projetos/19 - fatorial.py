numero_fatorial = int(input('Digite a um numero e descubra seu fatorial: '))
fatorial = 0 
for c in range(numero_fatorial - 1,0, -1):
    
    fatorial = numero_fatorial * c
    print(numero_fatorial,'!' ,'x', c, '=', fatorial )
