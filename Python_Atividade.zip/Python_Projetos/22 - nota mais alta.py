list_notas = []
print("Digite as notas dos estudantes (ou digite -1 para encerrar):")

while True:
    notas = float(input("Digite a nota: "))
    
    if notas == -1:
        break
 
    list_notas.append(notas)

if list_notas:
    maior_nota = max(list_notas)
    print(f"\nTodas as notas registradas: {list_notas}")
    print(f"A maior nota da turma foi: {maior_nota}")
else:
    print("\nNenhuma nota foi registrada.")
