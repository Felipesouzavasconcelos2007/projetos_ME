for indentificacao in range(1,51):
    print('Visitante',indentificacao)