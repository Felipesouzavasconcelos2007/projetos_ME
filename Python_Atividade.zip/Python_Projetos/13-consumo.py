consumo1 = float(input('Digite o gasto do setor 1: '))
consumo2 = float(input('Digite o gasto do setor 2: '))

if consumo1 > consumo2:
    print('O consumo do setor 1 foi o mais alto!')
elif consumo2 > consumo1:
    print('O consumo do setor 2 foi o mais alto!')
else:
    print('Os setores tiveram o mesmo consumo!')