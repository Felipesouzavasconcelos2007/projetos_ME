alunos_notas = {
    "João" : 10.0,
    "Carlos" : 6.0,
    "Ana" : 8.0,
    "Julia": 10.0
}
nome_aluno = input('Digite o nome do aluno que deseja ver a nota: ')

print('A nota do aluno(a) foi', alunos_notas[nome_aluno])