from random import randint
num_sorteado = randint(1,10000)

while True:
    palpite = int(input('De seu palpite: '))

    if palpite != num_sorteado:
        if palpite < num_sorteado:
            print('O numero sorte a do é maior!')
        elif palpite > num_sorteado:
            print('O numero sorte a do é menor! ')
    elif palpite == num_sorteado:
        print('Parabens você acertou!!!!')
        break
    else:
        continue
                  
