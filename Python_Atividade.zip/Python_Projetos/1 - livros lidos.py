livros_lidos = int(input('Digite a quantidade de livros lidos: '))
print(f'O total de livros lidos foi: {livros_lidos}')