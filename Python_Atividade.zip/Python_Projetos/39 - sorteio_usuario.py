from random import randint
num_user = int(input('Digite um numero: '))
num_robo = randint(1,10)

if num_robo == num_user:
    print("Você acertou o numero sorteado!!!")
else:
    print("Você errou!!! O numero sorteado foi",num_robo)