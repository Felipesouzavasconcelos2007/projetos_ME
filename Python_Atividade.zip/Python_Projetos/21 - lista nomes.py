list_nomes = []
for nomes in range(5):
    nome = str(input(' Digite o nome do produto: '))
    list_nomes.append(nome)

print(list_nomes)
