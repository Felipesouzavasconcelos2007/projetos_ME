#Uma cooperativa agrícola utiliza uma estufa automatizada para o cultivo de hortaliças. Durante cinco dias consecutivos, 
# sensores registram as temperaturas médias internas da estufa. 
# Essas temperaturas devem ser armazenadas para posterior análise da equipe técnica. 
# O sistema deverá: 
#Ler as temperaturas dos cinco dias. 

#Armazená-las em uma lista. 
#Calcular a média das temperaturas registradas. 
#Informar se a média está dentro da faixa ideal de cultivo (entre 18°C e 28°C). 
#Exibir todas as temperaturas cadastradas. 

list_temp = []
soma = 0
for temp in range(5):
    temperaturas = float(input('Digite a temperatura: '))
    list_temp.append(temperaturas)
    soma +=temperaturas

media = soma / (len(list_temp))
if media >= 18 and media <= 28:
    print('TEMPERATURA IDEAL!!')
else:
    print('TEMPERATURA FORA DA FAIXA IDEAL!!')

print('As temperaturas coletadas foram...',list_temp)