valores = [
    [123,345,567],
    [789,101,111],
    [121,131,141]
]

for i in range(len(valores)):
    print(valores[i][i])