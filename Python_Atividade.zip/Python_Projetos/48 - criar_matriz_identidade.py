matriz = []

for line in range(3):
    linha = []

    for coluna in range(3):
        if line == coluna:
            linha.append(1)
        else:
            linha.append(0)
        
    matriz.append(linha)

for linha in matriz:
    print(linha)