soma = 0 
while True:
    num = int(input('Digite um numero: '))
    soma +=num
    if num == 0 : 
        break
    else:
        continue

print(f'A soma de todos os numeros digitados foi: {soma}')
    
