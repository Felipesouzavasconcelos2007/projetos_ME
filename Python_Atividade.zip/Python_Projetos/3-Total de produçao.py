coperativa1= int(input('Digite a quantidade de produçao da Coperativa A: '))
coperativa2 = int(input('Digite a quantidade de produção da Coperativa B: '))
soma = coperativa1 + coperativa2
print(f'O total da produção foi: {soma}')