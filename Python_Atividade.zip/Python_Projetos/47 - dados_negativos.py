valores = [
    [-123,345,567],
    [789,-101,-111],
    [121,-131,141]
]
cont = 0
for linha in valores:
    for num in linha:
        if num > 0 :
            cont+=1
print(cont)