list_livros =[]
for titulos in range(3):
    ttl_livros= str(input('Digite seus titulos lidos: ' ))
    list_livros.append(ttl_livros)
print(f'Os livros cadastrados são:  {list_livros}')