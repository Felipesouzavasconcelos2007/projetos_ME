valores = [
    [123,345,567],
    [789,101,111],
    [121,131,141]
]

menor_valor = valores[0][0]

for linha in valores:
    for num in linha:
        if menor_valor >= num:
            menor_valor = num

print(menor_valor)
