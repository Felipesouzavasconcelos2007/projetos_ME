quadrado = 0
graos = 1
soma = 0

while quadrado <= 63:
    quadrado += 1
    if quadrado > 1:
        graos = graos * 2
        soma += graos 
        print('Quadrado',quadrado,'tem',graos,'grãos')
print('A rainha terá que pagar' ,soma, 'grãos')