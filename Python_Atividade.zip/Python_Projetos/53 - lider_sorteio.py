from random import choice
estudantes = ['Ana', 'Carlos', 'Beatriz', 'Pedro', 'Maria']
sorteio = choice(estudantes)
print('O ganhador foi:',sorteio)