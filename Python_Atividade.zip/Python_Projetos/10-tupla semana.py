tupla_semana = ('domingo','segunda','terça','quarta','quinta','sexta','sabado')
print(f'O primeiro dia da semana é : {tupla_semana[0]}')