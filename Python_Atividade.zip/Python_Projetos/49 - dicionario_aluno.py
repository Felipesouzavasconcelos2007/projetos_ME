dicionario_alunos = {
}
for cadastro in range(5):
    nome_aluno = str(input("Digite o nome do seu aluno: "))
    nota_aluno = float(input('Dite a nota do seu aluno: '))
    dicionario_alunos[nome_aluno] = nota_aluno

for nome , nota in dicionario_alunos.items():
    print(f'Aluno: {nome} | Nota: {nota}')
