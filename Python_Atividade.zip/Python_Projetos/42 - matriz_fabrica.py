setores = [
    [200,300,700],
    [300,450,222],
    [400,340,277]
]
soma = 0
for linha in setores:
    for num in linha:
        soma+=num


print("A soma dos valores da matriz deu :",soma)