livros = {
    "titulo": "Dom Casmurro" ,
    "autor":  "Machado de Assis",
    "ano":  1899,
    "tema": "Romance"
}
print(livros.keys())