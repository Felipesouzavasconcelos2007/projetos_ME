nome = str(input('Digite seu nome: '))
idade = int(input('Digite sua idade: '))
setor = str(input('Digite seu setor: '))

funcionario =  {
    "nome" : nome ,
    "idade" : idade , 
    "setor" : setor ,
}

print("Nome: ", funcionario["nome"])
print("Idade: ",funcionario["idade"])
print("Setor: ",funcionario["setor"])