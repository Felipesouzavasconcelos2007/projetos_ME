valores = [
    [123,345,567],
    [789,101,111],
    [121,131,141]
]

maior_valor = valores[0][0]

for linha in valores:
    for valor in linha :
        if valor > maior_valor:
            maior_valor = valor

print('O maior valor foi:',maior_valor) 