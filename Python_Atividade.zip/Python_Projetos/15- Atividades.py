for atividades in range(1,16):
    print(f'atividade {atividades}')