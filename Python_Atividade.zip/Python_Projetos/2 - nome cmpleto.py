nome_comp = str(input('Digite seu nome completo: '))
print(f'Bem vindo {nome_comp}!!!! ')