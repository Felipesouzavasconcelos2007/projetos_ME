from random import randint

list_livros = ["Harry Pother", "Interestelar", "Star Wars", "Quarto de Despejo"]

num_do_livro = randint(1, len(list_livros))

print(list_livros[num_do_livro])