nota1 = float(input('Digite a primeira nota do aluno: '))
nota2 = float(input('Digite a segumda nota do aluno: '))

media_est = (nota1 + nota2) / 2

print(f'A media do aluno foi {media_est}')
