meses_do_ano = ('Janeiro','Fevereiro ','Março','Abril', 'Maio','Junho','julho','Agosto', 'Setembro','Outubro','Novenbro', 'Dezembro')
for meses in meses_do_ano:
    print(meses)