paciente = {
    "nome" : "Paulo"
}

paciente["idade"] = 25

print(paciente)