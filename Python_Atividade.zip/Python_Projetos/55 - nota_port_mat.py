disciplinas = ('Português', 'Matematica')

dict_nome_nota = {
    "Ana" : [10.0 , 8.0],
    "Pedro" : [4.0, 7.0],
    "Cleiton" : [7.0 , 7.0]
}
situacao = ''
print('As disciplinas cadastradas são:', disciplinas)
print('-------------------------------------------')

for nome, notas in dict_nome_nota.items():
    media = sum(notas) / len(notas)
    if media >= 7:
        situacao = ('Aprovado!!!')
    else:
        situacao = ('Reprovado!!!')

    print('Aluno :',nome)
    print('Media:',media)
    print('Situação:',situacao)
    print(40*'*')
    