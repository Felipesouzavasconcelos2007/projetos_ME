letivo_tupla = ("segunda", "terça", "quarta", "quinta", "sexta")
print(f'O ultimo dia da semana letiva foi {letivo_tupla[-1]}')
