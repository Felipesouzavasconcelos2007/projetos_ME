soma = 0
for cestas in range(10):
    qutdd_cestas = int(input('Digite a quantidade de cestas arrecadadas por você: '))
    soma+=qutdd_cestas
    
print(soma)