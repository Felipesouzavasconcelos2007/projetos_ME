list_semana = ['domingo','segunda','terça','quarta','quinta','sexta','sabado']
soma = 0
for vendas in range(7):
    ttl_vend = int(input(f'Digite a quantidade de venda do(a) {list_semana[vendas]}: '))
    soma +=ttl_vend

print(f'O total de vendas da semana foi: {soma} itens')
