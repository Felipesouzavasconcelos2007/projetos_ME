def buscar_permissao(perfis, perfil, indice):
    try:
        print(f'Permssão para : {perfis[perfil][indice]}')
    except KeyError:
        return 'acesso_restrito'
    except IndexError:
        return 'acesso_restrito'


perfis = {
    'admin': ['ler', 'escrever', 'excluir'],
    'editor': ['ler', 'escrever'],
    'visitante': ['ler'],
}


buscar_permissao(perfis,'editor',1)