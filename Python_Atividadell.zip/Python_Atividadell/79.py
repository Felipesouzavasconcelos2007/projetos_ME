# Crie uma função. Requisitos:  
# • Nome não pode ser vazio.  
# • Preço maior que zero.  
# • Quantidade não negativa.  
# • Lançar exceções adequadas.  
# • Retornar mensagem de sucesso.   



def cadastrar_produto(nome, preco, quantidade):

        if not isinstance(nome, str):
            raise TypeError('O nome deve ser um texto!')
        
        if not isinstance(preco, (int, float)) or isinstance(preco, bool):
            raise TypeError('O preço deve ser um número!')
        
        if not isinstance(quantidade, int) or isinstance(quantidade, bool):
            raise TypeError('A quantidade deve ser um número inteiro!')

        if nome == '':
            raise ValueError('O nome não pode ficar vazio!')

        if preco <= 0 :
            raise ValueError('O valor não pode estar vazio!')

        if quantidade < 0 :
            raise ValueError('A quantiddade não pode ser menor que zero!')

        return f'''Produto {nome} cadastrado com sucesso!!!
Preço = {preco} / Quantidade = {quantidade}'''

   
try:
    nome = str(input('Digite o nome do produto: '))
    preco = float(input('Digite o preço do poduto: '))
    quantidade = int(input('Digite a quantidade de produtos: '))

    print(cadastrar_produto(nome,preco,quantidade)) 

except (ValueError,TypeError) as erro:
    print(erro)