def par_impar(a,b):
    if a % 2 == 0 and b % 2 == 0:
        if a < b :
            print(a)
        else:
            print(b)
    else:
        if a < b :
            print(b)
        else:
            print(a)

num = int(input('Digite seu numero: '))
num1 = int(input('Digite seu numero: '))

par_impar(num,num1)