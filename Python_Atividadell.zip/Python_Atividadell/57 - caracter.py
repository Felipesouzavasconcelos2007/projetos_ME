def quantas_vzs_caractr(caracter , str):
    quant = str.count(caracter)
    print(f"O caracter '{caracter}' aparece {quant}")

string = str(input('Digite a sua frase aqui: '))
quantidade = str(input('Digite a caracter que você quer saber quantas vezes aparece: '))

quantas_vzs_caractr(quantidade,string)