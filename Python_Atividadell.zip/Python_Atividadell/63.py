numeros = []
def cinco_num(num):
    
    for numero in range(5):
        num5 = int(input(f'Digite o {numero + 1}° numero: '))
        num.append(num5)
    
def maior_num(num):
    maior_numero = max(num)
    return maior_numero

def menor_num(num):
    menor_numero = min(num)
    return menor_numero

cinco_num(numeros)
print(f'O maior numero foi {maior_num(numeros)}')
print(f'O menor numero foi {menor_num(numeros)}')

