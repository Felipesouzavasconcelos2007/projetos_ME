#Escrever uma função para inverter as seguintes strings.  

#"python2023"  

 #"0203programacao2023"  

#"luz azul"  

#"arara rara"  

#anotaram a data da maratona"


list = ["0203programacao2023" ,"luz azul" ,"arara rara" , 
        "anotaram a data da maratona" ]

def invert(a):
    
    list_invertida = []

    for frase in a:
        palavras  = frase.split()
        palavras = palavras[::-1]
        frase1 = ''.join(palavras)
        list_invertida.append(frase1)

    print(list_invertida)

invert(list)

