class ProdutoInvalidoError(Exception):
    pass


class ValorInvalidoError(Exception):
    pass


class QuantidadeInvalidaError(Exception):
    pass


def registrar_venda(produto, preco, quantidade):
    if produto == '':
        raise ProdutoInvalidoError('Produto não pode ficar vazio!')

    if preco <= 0:
        raise ValorInvalidoError('Valor de produto inválido!')

    if not isinstance(quantidade, int) or quantidade <= 0:
        raise QuantidadeInvalidaError('Quantidade de produto inválida!')

    return {
        "produto": produto,
        "preco": preco,
        "quantidade": quantidade,
        "total": preco * quantidade,
    }


def gerar_relatorio(vendas):
    qtd_vendas = len(vendas)
    faturamento = sum(v["total"] for v in vendas)

    por_produto = {}
    for v in vendas:
        nome = v["produto"]
        por_produto[nome] = por_produto.get(nome, 0) + v["quantidade"]

    mais_vendido = max(por_produto, key=por_produto.get)

    return f'''A quantidade total de vendas foi {qtd_vendas}
O produto mais vendido foi {mais_vendido}
Faturamento total da loja: R$ {faturamento:.2f}
Ticket médio por venda: R$ {faturamento / qtd_vendas:.2f}'''


vendas = []

while True:
    produto = input("Digite o nome do produto (Digite 'fim' para finalizar): ").strip().upper()

    if produto == 'FIM':
        print('Programa finalizado')
        break

    try:
        preco = float(input('Digite o preço do produto: '))
        quantidade = int(input('Digite a quantidade do produto: '))
        venda = registrar_venda(produto, preco, quantidade)

    except ValueError:
        print('Erro: preço e quantidade devem ser números válidos!')

    except (ProdutoInvalidoError, ValorInvalidoError, QuantidadeInvalidaError) as erro:
        print(f'Erro: {erro}')

    else:
        vendas.append(venda)
        print('Venda registrada com sucesso!')

    finally:
        print(f'Vendas válidas até agora: {len(vendas)}\n')

if vendas:
    print(gerar_relatorio(vendas))
else:
    print('Nenhuma venda registrada.')