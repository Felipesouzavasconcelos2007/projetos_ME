import random

def conexao_mock():
    if random.random() < 0.7:
        raise ConnectionError('A conexão falhou!!')
    return 'Conectado'

def conectar_retry():
    limite = 3
    for tentativa in range(1, 4):

        try:
            resultado = conexao_mock()

        except ConnectionError:
            print(f'Tentativa {tentativa}/{limite} Falhou!')

        else:
            print(f'Sucesso na tentativa {tentativa}!')
            return resultado

    print('Falha: limite de tentativas alcançado!!!')

    return None

conectar_retry()


