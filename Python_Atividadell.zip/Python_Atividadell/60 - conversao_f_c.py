def conversao(faren):
    c = (5/9) * (temp_far - 32)
    print(f'A conversão de {round(temp_far, 1)}°F é {round(c, 1)}°C')

temp_far = float(input('Digite a temperatura em °F que vc deseja converter para °C: '))

conversao(temp_far)
