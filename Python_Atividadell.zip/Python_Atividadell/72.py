cpf0 = []
def parse_cpf(cpf):

    if not cpf.isdigit():
        raise ValueError('O CPF so deve ter numeros')

    if int(len(cpf)) < 11 or int(len(cpf)) > 11:
        raise ValueError('O CPF deve ter 11 digitos!')

    return cpf
       

def main(lista):
    
    cpf = input('Digite o seu CPF: ')
    
    try:
        cpf_valido = parse_cpf(cpf)
        lista.append(cpf_valido)
    except ValueError as erro:
        print(erro)

    return cpf_valido

print(f' O CPF: {main(cpf0)}, é valido!')

    