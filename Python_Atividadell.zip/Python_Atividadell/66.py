def galinhasecoelhos(p,c):
    coelhos = (p - 2 * c) / 2
    galinhas = c - coelhos

    print(f'''Na sua fazenda tem {int(coelhos)} coelhos e {int(galinhas)} galinhas.''')

galinhasecoelhos(94,35)