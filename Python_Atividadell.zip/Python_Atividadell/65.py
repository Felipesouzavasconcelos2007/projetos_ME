def cacularCubo(num):
    cubo = num**3
    return cubo

def calcularDivisaoCubo(num):
    if num % 3 == 0 :
        cubbo = cacularCubo(num)
        print('Seu numero é divisivel por três, esse é ele se for elevado ao cubo:')
        return cubbo
    else:
        print('Seu numero não é divisivel por 3')
        return False

numero = int(input('DIGITE UM NUMERO: '))

print(f'{numero} ao cubo é : {cacularCubo(numero)}')
print(calcularDivisaoCubo(numero))