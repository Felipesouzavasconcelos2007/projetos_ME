def vinteium():
    numer = []
    try:
        for n in range(3):
            num = int(input('Digite um numero: '))
            numer.append(num)
            if num > 11 or num < 1:
                raise ValueError('O PROGRAMA SO ACEITA NUMEROS ENTRE 1 E 11!!')
    except ValueError as erro:
        print(erro)   

    soma = sum(numer)     

    if soma <= 21:
        return soma
    
    if soma > 21 and 11 in numer:
        soma -= 10

    if soma > 21 :
        return -1

    return soma
    
   

print(vinteium())