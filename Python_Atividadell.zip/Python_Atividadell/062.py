#Escrever uma função para verificar se um número é perfeito. 
#Um número perfeito é um número natural que 
#é igual à soma de todos os seus divisores positivos, excluindo o próprio número.  
#Exemplos:  
#- 6, pois 1 + 2 + 3 = 6  

#- 28, pois 1 + 2 + 4 + 7 + 14 = 28 

numero_perfeito = int(input('Digite um numero e descubra se ele é um numero perfeito: '))

def num_perfeito(num):
    numeros_somaveis = []

    for numero in range(1,num):
        if num % numero == 0:
            numeros_somaveis.append(numero)

    soma = sum(numeros_somaveis)
    
    if soma == num:
        print(f'O numero {num} é um numero perfeito!')
    
    else:
        print(f'O numero {num} não é um numero perfeito!')

num_perfeito(numero_perfeito)