def relatorio():
    arquivo = None
    try:
        arquivo = open('relatorio_vendas.txt', 'r', encoding='utf-8')
        conteudo = arquivo.read()
        print(conteudo)
    except FileNotFoundError:
        print("ERRO! o arquivo 'relatorio_de_venda.txt' não foi encontrado!")

    finally:
        if arquivo is not None :
            arquivo.close()
        print('Programa finalizado!!')
    
relatorio()