l_preços = ['1111','2123','67','89','sasdd']

for valores in l_preços:
    try:    
        valor = float(valores)
    except ValueError:
        print(f"Valor '{valores}' é invalido!!")

    else :
        desconto = valor * 0.90
        print(f'Preço sem desconto R${valor} --> Com desconto R${desconto:.2}')
