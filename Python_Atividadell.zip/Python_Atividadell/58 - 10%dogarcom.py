def dez_garcon(valor_conta):
    dez_porcento = (valor_conta * 0.10) + valor_conta
    return dez_porcento

conta = float(input('Digite o valor da sua conta: '))

print(f'O valor com os 10% do garçom fica {dez_garcon(conta)}')
