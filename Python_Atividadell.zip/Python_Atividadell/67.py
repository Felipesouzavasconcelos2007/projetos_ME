def cadastro():
    
    while True:
        try:    
            idade = int(input('Digite sua idade: '))

            if idade < 0:
                raise ValueError('A idade deve ser maior que zero!!!')

            else:
                print('Idade adicionada a ficha cadastral!')
                break

        except ValueError as erro:
            print(erro)

cadastro()

    