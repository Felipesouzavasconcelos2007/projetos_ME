produtos_dic = {1: "Teclado", 2: "Mouse", 3: None}


def rota_produto(produto_id):
    try:
        produto = produtos_dic[produto_id]
        nome = produto.upper()
    except KeyError:
        return {"erro": "Produto não encontrado"}, 404
    except Exception:
        return {"erro": "Erro interno do servidor"}, 500
    else:
        return {"id": produto_id, "nome": nome}, 200


for id_teste in (1, 99, 3):
    print(f"GET /produto/{id_teste} -> {rota_produto(id_teste)}")
