def calcular_media(n1, n2, n3):
    nlist= [n1,n2,n3]
    try:
        for nota in nlist:
            if nota > 10 or nota < 0:
                raise Exception('A nota deve se um numero entre 0.0 e 10.0')

            if not isinstance(nota,(int,float) or isinstance(nota,bool)):
                raise TypeError('Digite apenas numeros!!')
  
        media = sum(nlist) / len(nlist)
        media_format = (f'{media:.2f}')

        if media > 6.0:
            print('''Aluno aprovado!!
Media: ''')
            return media_format

        else:
            print ('''Aluno reprovado!!
Media: ''')
            return media_format
        
    except Exception as erro1:
        print(erro1)

    except (ValueError , TypeError) as erro2:
        print(erro2)


try:
    n1 = float(input('Digite a primeira nota: '))
    n2 = float(input('Digite a segunda nota: '))
    n3 = float(input('Digite a terceira nota: '))

    print(calcular_media(n1,n2,n3))

except ValueError:
    print('Ocorreu um erro!!')