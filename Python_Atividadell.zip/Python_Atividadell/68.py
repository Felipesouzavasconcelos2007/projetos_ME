def divLucros():

    try:
        lucro = float(input('Digite o valor dos lucros: '))
        acionistas = int(input('Digite a quantidade de acionistas: '))

        valor_por_acionista = lucro / acionistas

    except ValueError:
        print(ValueError)

    except ZeroDivisionError:
        print(ZeroDivisionError)

    print(f'O valor por acionista é : {valor_por_acionista:.2f}')

divLucros()