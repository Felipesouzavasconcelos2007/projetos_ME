class SaldoInsuficienteError(Exception):

    def __init__(self,saldo,valor):
        self.saldo = saldo
        self.valor = valor
        super().__init__(
            f'Saldo insuficiente: saldo atual R$ {saldo:.2f}. ,'
            f'Saque solicitado r$ {valor:.2f}.'
        )

def sacar(saldo , valor):
    try:    
        if valor > saldo :
            raise SaldoInsuficienteError(saldo,valor)
        return saldo - valor

    except SaldoInsuficienteError as erro:
        print(f'Operação negada. {erro}')



saldo = 400

print(f'O saldo restante é : R$ {sacar(saldo, 800)}')