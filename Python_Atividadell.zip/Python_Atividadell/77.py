saldo = 10000
valor_saque = float(input('Digite o valor de saque: '))

def realizar_saque(saldo, valor_saque):
    try:
        saque_valido = valor_saque > 0 
        saldo_insuficiente = saldo < valor_saque
       
        if saque_valido == False:
            raise Exception('Valor de saque invalido!')
        if saldo_insuficiente == True:
            raise Exception('Saldo insuficiente!')

    except Exception as erro:
        print(erro)
    saldo = saldo - valor_saque
    return saldo

saldo_final = realizar_saque(saldo,valor_saque)

print(f'O seu saldo agora é : R${saldo_final:.2f}')
        
