import traceback

dados = ['dsd',12213,5665,7,33,'af','...','dfa']

def processar_dados(lista):

    validos = []

    for item in lista:

        try:
            valor = float(item)

        except (ValueError,TypeError):
            print(f"Dado invalido '{item}'")
            traceback.print_exc()

        else:
            validos.append(valor)
    return validos

resultado = processar_dados(dados)
print(f'Processados : {resultado}')
